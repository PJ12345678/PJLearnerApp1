package hhird.harsh123.com.learnerapp;

public class ytvid {

    String vidurl;

    public ytvid(){

    }
    public ytvid(String vidurl){this.vidurl=vidurl;}


    public String getVidurl() {
        return vidurl;
    }
}
