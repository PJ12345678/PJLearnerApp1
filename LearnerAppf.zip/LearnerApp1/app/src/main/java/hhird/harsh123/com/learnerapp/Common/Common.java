package hhird.harsh123.com.learnerapp.Common;

public class Common {

    public static int quetot = 20;
    public int que=Integer.parseInt(null);
    public int queuploaded=Integer.parseInt(null);



}
